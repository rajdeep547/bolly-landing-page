<?php

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

delete_option('bolly_landing_page_id');
