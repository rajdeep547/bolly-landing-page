const { execSync } = require('child_process');
const path = require('path');

const projectRoot = path.resolve(__dirname, '..');

function run(command) {
  console.log(`\n> ${command}`);
  execSync(command, { stdio: 'inherit', cwd: projectRoot, shell: true });
}

function sleep(ms) {
  Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
}

function wp(command) {
  run(`docker compose exec -T wpcli wp ${command} --allow-root`);
}

console.log('Starting Bolly WordPress environment...');
run('docker compose up -d');

console.log('Waiting for WordPress to become ready...');
for (let attempt = 0; attempt < 30; attempt += 1) {
  try {
    execSync('docker compose exec -T wpcli wp core is-installed --allow-root', {
      stdio: 'pipe',
      cwd: projectRoot,
      shell: true,
    });
    break;
  } catch (error) {
    if (attempt === 0) {
      try {
        wp('core install --url=http://localhost:8080 --title="Bolly" --admin_user=admin --admin_password=admin123 --admin_email=admin@example.com --skip-email');
      } catch (installError) {
        // Retry until WordPress is reachable.
      }
    }
    sleep(4000);
  }
}

try {
  wp('core is-installed');
} catch (error) {
  wp('core install --url=http://localhost:8080 --title="Bolly" --admin_user=admin --admin_password=admin123 --admin_email=admin@example.com --skip-email');
}

wp('plugin install elementor --activate');
wp('plugin activate bolly-landing');
wp('rewrite structure /%postname%/ --hard');
wp('option update show_on_front page');

const pages = execSync('docker compose exec -T wpcli wp post list --post_type=page --name=bolly-landing --field=ID --allow-root', {
  cwd: projectRoot,
  shell: true,
  encoding: 'utf8',
}).trim();

if (!pages) {
  wp('eval "Bolly_Installer::create_landing_page();"');
}

const pageId = execSync('docker compose exec -T wpcli wp post list --post_type=page --name=bolly-landing --field=ID --allow-root', {
  cwd: projectRoot,
  shell: true,
  encoding: 'utf8',
}).trim();

if (pageId) {
  wp(`option update page_on_front ${pageId}`);
  wp(`post update ${pageId} --post_status=publish`);
}

console.log('\nSetup complete.');
console.log('Site:      http://localhost:8080');
console.log('Admin:     http://localhost:8080/wp-admin');
console.log('Login:     admin / admin123');
